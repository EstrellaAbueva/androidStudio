package com.example.bingogame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    ArrayList<String> arrayList;
    ArrayAdapter<String> arrayAdapter;
    String token;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void setToken(String tok){
        this.token = tok;
    }

    public void set(){
        Button b1 = findViewById(R.id.button1);
        Button b2 = findViewById(R.id.button2);
        Button b3 = findViewById(R.id.button3);
        Button b4 = findViewById(R.id.button4);
        Button b5 = findViewById(R.id.button5);
        Button b6 = findViewById(R.id.button6);
        Button b7 = findViewById(R.id.button7);
        Button b8 = findViewById(R.id.button8);
        Button b9 = findViewById(R.id.button9);
        Button b10 = findViewById(R.id.button10);
        Button b11 = findViewById(R.id.button11);
        Button b12 = findViewById(R.id.button12);
        Button b13 = findViewById(R.id.button13);
        Button b14 = findViewById(R.id.button14);
        Button b15 = findViewById(R.id.button15);
        Button b16 = findViewById(R.id.button16);
        Button b17 = findViewById(R.id.button17);
        Button b18 = findViewById(R.id.button18);
        Button b19 = findViewById(R.id.button19);
        Button b20 = findViewById(R.id.button20);
        Button b21 = findViewById(R.id.button21);
        Button b22 = findViewById(R.id.button22);
        Button b23 = findViewById(R.id.button23);
        Button b24 = findViewById(R.id.button24);
        Button b25 = findViewById(R.id.button25);

        b1.setEnabled(true);
        b2.setEnabled(true);
        b3.setEnabled(true);
        b4.setEnabled(true);
        b5.setEnabled(true);
        b6.setEnabled(true);
        b7.setEnabled(true);
        b8.setEnabled(true);
        b9.setEnabled(true);
        b10.setEnabled(true);
        b11.setEnabled(true);
        b12.setEnabled(true);
        b13.setEnabled(true);
        b14.setEnabled(true);
        b15.setEnabled(true);
        b16.setEnabled(true);
        b17.setEnabled(true);
        b18.setEnabled(true);
        b19.setEnabled(true);
        b20.setEnabled(true);
        b21.setEnabled(true);
        b22.setEnabled(true);
        b23.setEnabled(true);
        b24.setEnabled(true);
        b25.setEnabled(true);

        ((TextView) findViewById(R.id.res2)).setText("");
    }
    public void clicked(View view) {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "http://www.hyeumine.com/getcard.php?bcode="+ ((EditText)findViewById(R.id.code)).getText().toString();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                       // ((TextView) findViewById(R.id.tv)).setText(response);
                        try{
                            JSONObject cardData = new JSONObject (response);
                            token = cardData.getString("playcard_token");
                            setToken(token);
                            JSONObject bingoCard = cardData.getJSONObject("card");
                            set();

                            JSONArray arr_B = bingoCard.getJSONArray("B");
                            List<String> exampleList = new ArrayList<String>();
                            for (int i = 0; i < arr_B.length(); i++) {
                                exampleList.add(arr_B.getString(i));
                                System.out.println(exampleList);
                            }

                            int size = exampleList.size();
                            String[] stringArray = exampleList.toArray(new String[size]);

                            ((Button) findViewById(R.id.button1)).setText(stringArray[0]);
                            ((Button) findViewById(R.id.button6)).setText(stringArray[1]);
                            ((Button) findViewById(R.id.button11)).setText(stringArray[2]);
                            ((Button) findViewById(R.id.button16)).setText(stringArray[3]);
                            ((Button) findViewById(R.id.button21)).setText(stringArray[4]);

                            JSONArray arr_I = bingoCard.getJSONArray("I");
                            List<String> exampleList2 = new ArrayList<String>();
                            for (int i = 0; i < arr_I.length(); i++) {
                                exampleList2.add(arr_I.getString(i));
                                System.out.println(exampleList2);
                            }

                            int size2 = exampleList2.size();
                            String[] stringArray2 = exampleList2.toArray(new String[size2]);

                            ((Button) findViewById(R.id.button2)).setText(stringArray2[0]);
                            ((Button) findViewById(R.id.button7)).setText(stringArray2[1]);
                            ((Button) findViewById(R.id.button12)).setText(stringArray2[2]);
                            ((Button) findViewById(R.id.button17)).setText(stringArray2[3]);
                            ((Button) findViewById(R.id.button22)).setText(stringArray2[4]);

                            JSONArray arr_N = bingoCard.getJSONArray("N");
                            List<String> exampleList3 = new ArrayList<String>();
                            for (int i = 0; i < arr_N.length(); i++) {
                                exampleList3.add(arr_N.getString(i));
                                System.out.println(exampleList3);
                            }

                            int size3 = exampleList3.size();
                            String[] stringArray3 = exampleList3.toArray(new String[size3]);

                            ((Button) findViewById(R.id.button3)).setText(stringArray3[0]);
                            ((Button) findViewById(R.id.button8)).setText(stringArray3[1]);
                            ((Button) findViewById(R.id.button13)).setText(stringArray3[2]);
                            ((Button) findViewById(R.id.button18)).setText(stringArray3[3]);
                            ((Button) findViewById(R.id.button23)).setText(stringArray3[4]);

                            JSONArray arr_G = bingoCard.getJSONArray("G");
                            List<String> exampleList4 = new ArrayList<String>();
                            for (int i = 0; i < arr_G.length(); i++) {
                                exampleList4.add(arr_G.getString(i));
                                System.out.println(exampleList4);
                            }

                            int size4 = exampleList4.size();
                            String[] stringArray4 = exampleList4.toArray(new String[size4]);

                            ((Button) findViewById(R.id.button4)).setText(stringArray4[0]);
                            ((Button) findViewById(R.id.button9)).setText(stringArray4[1]);
                            ((Button) findViewById(R.id.button14)).setText(stringArray4[2]);
                            ((Button) findViewById(R.id.button19)).setText(stringArray4[3]);
                            ((Button) findViewById(R.id.button24)).setText(stringArray4[4]);

                            JSONArray arr_O = bingoCard.getJSONArray("O");
                            List<String> exampleList5 = new ArrayList<String>();
                            for (int i = 0; i < arr_O.length(); i++) {
                                exampleList5.add(arr_O.getString(i));
                                System.out.println(exampleList5);
                            }

                            int size5 = exampleList5.size();
                            String[] stringArray5 = exampleList5.toArray(new String[size5]);

                            ((Button) findViewById(R.id.button5)).setText(stringArray5[0]);
                            ((Button) findViewById(R.id.button10)).setText(stringArray5[1]);
                            ((Button) findViewById(R.id.button15)).setText(stringArray5[2]);
                            ((Button) findViewById(R.id.button20)).setText(stringArray5[3]);
                            ((Button) findViewById(R.id.button25)).setText(stringArray5[4]);

                        }catch (JSONException e){
                            System.out.println(e.toString());
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(">>", "Error connecting");
            }
        });

        queue.add(stringRequest);
    }

    public void onClick(View view) {
        Button b = (Button) view;
        b.setEnabled(false);
    }

    public void check(View view) {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "http://www.hyeumine.com/checkwin.php?playcard_token=" + token;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(MainActivity.this, "Winning Card?: " + response, Toast.LENGTH_LONG).show();
                        if(Integer.parseInt(response) == 1)
                            ((TextView) findViewById(R.id.res2)).setText("CONGRATULATIONS! YOU WON!");
                        else
                            ((TextView) findViewById(R.id.res2)).setText("SORRY! TRY AGAIN!");
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Something Went Wrong", Toast.LENGTH_LONG).show();
            }
        });

        queue.add(stringRequest);
    }
}