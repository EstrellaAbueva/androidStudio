package com.example.abueva_finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class activity_container_note extends AppCompatActivity {
    SharedPreferences sp;
    EditText titles, dates;
    String title, addDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_container_note);

        titles = findViewById(R.id.inputTitle);
        dates = findViewById(R.id.inputDate);

        title = titles.getText().toString();
        addDate = dates.getText().toString();
        setTitle(title);
        setDates(addDate);

        setContentView(R.layout.container_note);
        sp = getSharedPreferences("My_Prefs", Activity.MODE_PRIVATE);

        ((TextView)findViewById(R.id.textTitle)).setText(sp.getString("title","") );
        ((TextView)findViewById(R.id.textDate)).setText(sp.getString("date","") );


    }

    public void setTitle(String title){
        this.title = title;
    }

    public void setDates(String date){
        this.addDate = date;
    }
}