package com.example.abueva_finalproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    LayoutInflater inflater;
    List<NoteDatas> notes;
    OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onCLickItemListener(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    public Adapter(Context inflater, List<NoteDatas> notes) {
        this.inflater = LayoutInflater.from(inflater);
        this.notes = notes;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.container_note, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.image.setImageResource(notes.get(position).getImage());
        holder.notesNumber.setText(notes.get(position).getNotesNUmber());
        holder.noteTitle.setText(notes.get(position).getTitle());
        holder.noteNotes.setText(notes.get(position).getNotes());
        holder.noteDate.setText(notes.get(position).getDate());
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    public void filteredList (ArrayList <NoteDatas> noteslist){
         notes = noteslist;
         notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView image;
        TextView noteTitle, noteNotes, noteDate, notesNumber;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.imageView);
            notesNumber = itemView.findViewById(R.id.notesNumber);
            noteTitle = itemView.findViewById(R.id.textTitle);
            noteNotes = itemView.findViewById(R.id.textNotes);
            noteDate = itemView.findViewById(R.id.textDate);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(mListener != null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            mListener.onCLickItemListener(position);
                        }
                    }
                }
            });
        }
    }
}
