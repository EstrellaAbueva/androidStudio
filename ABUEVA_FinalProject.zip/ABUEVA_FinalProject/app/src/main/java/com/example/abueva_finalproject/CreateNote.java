package com.example.abueva_finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class CreateNote extends AppCompatActivity {
    SharedPreferences sp;
    EditText titles, notes, dates;
    Button submit;
    String title, note,  adddate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_note);

        ImageView imageback = findViewById(R.id.backImage);
        imageback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        titles = findViewById(R.id.inputTitle);
        notes = findViewById(R.id.inputNotes);
        dates = findViewById(R.id.inputDate);

        submit = findViewById(R.id.doneImage);

        sp = getSharedPreferences("My_Prefs", Activity.MODE_PRIVATE);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                title = titles.getText().toString();
                note = notes.getText().toString();
                adddate = dates.getText().toString();

                if (TextUtils.isEmpty(title)) {
                    titles.setError("Please Enter Title");
                } else if (TextUtils.isEmpty(note)) {
                    notes.setError("Please Enter Note");
                } else if (TextUtils.isEmpty(adddate)) {
                    dates.setError("Please Enter Date");
                } else {
                    addDataToDatabase(title, note, adddate);
                }
                openMainActivity();
            }
        });
    }

    public void setTitle(String title){
        this.title = title;
    }

    public void setDates(String date){
        this.adddate = date;
    }

    public void addDataToDatabase(String title, String note, String adddate){
        String url = "http://192.168.1.5/Abueva_FinalProject/insertInto.php";

        RequestQueue queue = Volley.newRequestQueue(CreateNote.this);

        StringRequest request = new StringRequest(Request.Method.POST, url, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("TAG", "RESPONSE IS " + response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Toast.makeText(CreateNote.this, "Successfully Added Notes", Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                titles.setText("");
                notes.setText("");
                dates.setText("");
                openMainActivity();
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(CreateNote.this, "Fail to get response: " + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded; charset=UTF-8";
            }

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();

                params.put("title", title);
                params.put("notes", note);
                params.put("date", adddate);

                return params;
            }
        };
        queue.add(request);
    }

    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}