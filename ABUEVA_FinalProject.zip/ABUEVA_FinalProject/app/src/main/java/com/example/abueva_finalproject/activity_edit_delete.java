package com.example.abueva_finalproject;

import static com.example.abueva_finalproject.MainActivity.EXTRA_DATE;
import static com.example.abueva_finalproject.MainActivity.EXTRA_NM;
import static com.example.abueva_finalproject.MainActivity.EXTRA_NOTE;
import static com.example.abueva_finalproject.MainActivity.EXTRA_TITLE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

public class activity_edit_delete extends AppCompatActivity {
    ImageView edit, delete;
    Intent intent;
    HashMap<String,String> hashMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_delete);

        ImageView imageback = findViewById(R.id.backImage);
        imageback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        intent = getIntent();

        String iTitle = intent.getStringExtra(EXTRA_TITLE);
        String iNotes = intent.getStringExtra(EXTRA_NOTE);
        String iDate = intent.getStringExtra(EXTRA_DATE);
        String iNotesNUmber = intent.getStringExtra(EXTRA_NM);

        EditText ed1 = findViewById(R.id.inputTitle);
        EditText ed2 = findViewById(R.id.inputNotes);
        EditText ed3 = findViewById(R.id.inputDate);
        TextView ed4 = findViewById(R.id.notesNums);

        ed1.setText(iTitle);
        ed2.setText(iNotes);
        ed3.setText(iDate);
        ed4.setText(iNotesNUmber);

        edit = findViewById(R.id.edit_icon);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(iTitle)) {
                    ed1.setError("Please Enter Title");
                } else if (TextUtils.isEmpty(iNotes)) {
                    ed2.setError("Please Enter Note");
                } else if (TextUtils.isEmpty(iDate)) {
                    ed3.setError("Please Enter Date");
                } else {
                    editIntoDatabase();
                }
                openMainActivity();
            }
        });


        delete = findViewById(R.id.delete_icon);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteIntodatabase();
                openMainActivity();
            }
        });
    }

    private void deleteIntodatabase() {
        String url = "http://192.168.1.5/Abueva_FinalProject/deleteInto.php";

        RequestQueue queue = Volley.newRequestQueue(activity_edit_delete.this);

        StringRequest request = new StringRequest(Request.Method.POST, url, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(activity_edit_delete.this, "Successfully Deleted Notes", Toast.LENGTH_SHORT).show();
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(activity_edit_delete.this, "Fail to get response: " + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            protected Map<String, String> getParams() {

                Map<String,String> params = new HashMap<String,String>();

                params.put("title", ((EditText)findViewById(R.id.inputTitle)).getText().toString());

                return params;
            }
        };
        queue.add(request);
    }

    private void editIntoDatabase() {
        String url = "http://192.168.1.5/Abueva_FinalProject/updateInto.php";

        RequestQueue queue = Volley.newRequestQueue(activity_edit_delete.this);

        StringRequest request = new StringRequest(Request.Method.POST, url, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(activity_edit_delete.this, "Successfully Edited Notes", Toast.LENGTH_SHORT).show();
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(activity_edit_delete.this, "Fail to get response: " + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            protected Map<String, String> getParams() {

                Map<String,String> params = new HashMap<String,String>();

                params.put("title", ((EditText)findViewById(R.id.inputTitle)).getText().toString());
                params.put("notes", ((EditText)findViewById(R.id.inputNotes)).getText().toString());
                params.put("date", ((EditText)findViewById(R.id.inputDate)).getText().toString());
                params.put("notesNumber", ((TextView)findViewById(R.id.notesNums)).getText().toString());

                System.out.println(((TextView)findViewById(R.id.notesNums)).getText().toString());

                return params;
            }
        };
        queue.add(request);
    }


    public void openMainActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}