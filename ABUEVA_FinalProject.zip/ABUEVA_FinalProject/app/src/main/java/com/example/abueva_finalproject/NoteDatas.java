package com.example.abueva_finalproject;

public class NoteDatas {
    private int image;
    private String title, notes, date, notesNUmber;

    public NoteDatas() {
    }

    public NoteDatas(int image, int notesNumber, String title, String notes, String date) {
        this.image = image;
        this.title = title;
        this.notes = notes;
        this.date = date;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getNotesNUmber() {
        return notesNUmber;
    }

    public void setNotesNUmber(String notesNUmber) {
        this.notesNUmber = notesNUmber;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
