package com.example.abueva_finalproject;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements Adapter.OnItemClickListener {
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_NOTE = "note";
    public static final String EXTRA_DATE = "date";
    public static final String EXTRA_NM = "notesNumber";

    SharedPreferences sp;
    RecyclerView recyclerView;
    List<NoteDatas> notes;
    Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.mainRecycler);

        extractNotes();

        sp = getSharedPreferences("My_Prefs", Activity.MODE_PRIVATE);

        ImageView imageAddNote = findViewById(R.id.add_button);
        imageAddNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               openCreateNote();
            }
        });

        EditText editText = findViewById(R.id.inputToSearch);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                filter(editable.toString());
            }
        });

    }

    private void filter(String text){
        ArrayList<NoteDatas> filteredList = new ArrayList<>();

        for(NoteDatas items: notes){
            if(items.getTitle().toLowerCase().contains(text.toLowerCase())){
                filteredList.add(items);
            }
        }

        adapter.filteredList(filteredList);
    }

    public void extractNotes() {
        notes = new ArrayList<>();
        RequestQueue queue2 = Volley.newRequestQueue(this);
        String JSON_URL = "http://192.168.1.5/Abueva_FinalProject/responseapi.php";

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, JSON_URL, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject noteObject = response.getJSONObject(i);

                        NoteDatas newNotes = new NoteDatas();
                        newNotes.setImage(R.drawable.ic_notes);
                        newNotes.setNotesNUmber(noteObject.getString("notesNumber").toString());
                        newNotes.setTitle(noteObject.getString("title").toString());
                        newNotes.setNotes(noteObject.getString("notes").toString());
                        newNotes.setDate(noteObject.getString("date").toString());


                        notes.add(newNotes);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                adapter = new Adapter(getApplicationContext(), notes);
                recyclerView.setAdapter(adapter);
                adapter.setOnItemClickListener(MainActivity.this);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("TAG", "onErrorResponse: " + error.getMessage());
            }
        });

        queue2.add(jsonArrayRequest);
    }

    public void openCreateNote(){
        Intent intent = new Intent(this, CreateNote.class);
        startActivity(intent);
    }

    public void openEditDelete(){
        Intent intent = new Intent(this, activity_edit_delete.class);
        startActivity(intent);
    }

    @Override
    public void onCLickItemListener(int position) {
        Intent intent = new Intent(this, activity_edit_delete.class);
        NoteDatas clickedItem = notes.get(position);

        intent.putExtra(EXTRA_TITLE, clickedItem.getTitle());
        intent.putExtra(EXTRA_NOTE, clickedItem.getNotes());
        intent.putExtra(EXTRA_DATE, clickedItem.getDate());
        intent.putExtra(EXTRA_NM, clickedItem.getNotesNUmber());

        startActivity(intent);
    }
}