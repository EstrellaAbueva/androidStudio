package com.example.abueva_midternexam;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    RandomNums newRand = new RandomNums();//RANDOM SA ARRAY 9-1
    int counter = 9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void valid(View v, int n) {
        Button b = (Button) v;
        b.setText(Integer.toString(n));//I OUTPUT ANG NUMBER SA BUTTON
    }

    public void invalid(View view){
        Button b = (Button) view;
        b.setText("");//SET TEXT INTO EMPTY
    }

    public void set(){
        Button but1 = findViewById(R.id.button1);
        Button but2 = findViewById(R.id.button2);
        Button but3 = findViewById(R.id.button3);
        Button but4 = findViewById(R.id.button4);
        Button but5 = findViewById(R.id.button5);
        Button but6 = findViewById(R.id.button6);
        Button but7 = findViewById(R.id.button7);
        Button but8 = findViewById(R.id.button8);
        Button but9 = findViewById(R.id.button9);

        invalid(but1);
        invalid(but2);
        invalid(but3);
        invalid(but4);
        invalid(but5);
        invalid(but6);
        invalid(but7);
        invalid(but8);
        invalid(but9);
    }

    public void onClick(View view) {
        Button b = (Button) view;
        switch (b.getId()){
           case R.id.button1:
                if(counter == newRand.getArray()[0]) {
                    valid(b, newRand.getArray()[0]);
                    counter -= 1;
                    if (newRand.getArray()[0] == 1) {
                        Toast.makeText(MainActivity.this,
                                "END GAME!", Toast.LENGTH_LONG).show();
                        break;
                    }
                }else{
                    counter = 9;
                    set();
                }
                break;
            case R.id.button2:
                if(counter == newRand.getArray()[1]) {
                    valid(b, newRand.getArray()[1]);
                    counter -= 1;
                     if (newRand.getArray()[1] == 1) {
                         Toast.makeText(MainActivity.this,
                                 "END GAME!", Toast.LENGTH_LONG).show();
                         break;
                     }
                }else{
                    counter = 9;
                    set();
                }
                break;
            case R.id.button3:
                if(counter == newRand.getArray()[2]) {
                    valid(b, newRand.getArray()[2]);
                    counter -= 1;
                     if (newRand.getArray()[2] == 1) {
                        Toast.makeText(MainActivity.this,
                                "END GAME!", Toast.LENGTH_LONG).show();
                        break;
                    }
                }else{
                    counter = 9;
                    set();
                }
                break;
            case R.id.button4:
                if(counter == newRand.getArray()[3]) {
                    valid(b, newRand.getArray()[3]);
                    counter -= 1;
                   if (newRand.getArray()[3] == 1) {
                        Toast.makeText(MainActivity.this,
                                "END GAME!", Toast.LENGTH_LONG).show();
                        break;
                    }
                }else{
                    counter = 9;
                    set();
                }
                break;
            case R.id.button5:
                if(counter == newRand.getArray()[4]) {
                    valid(b, newRand.getArray()[4]);
                    counter -= 1;
                     if (newRand.getArray()[4] == 1) {
                        Toast.makeText(MainActivity.this,
                                "END GAME!", Toast.LENGTH_LONG).show();
                        break;
                    }
                }else{
                    counter = 9;
                    set();
                }
                break;
            case R.id.button6:
                if(counter == newRand.getArray()[5]) {
                    valid(b, newRand.getArray()[5]);
                    counter -= 1;
                     if (newRand.getArray()[5] == 1) {
                        Toast.makeText(MainActivity.this,
                                "END GAME!", Toast.LENGTH_LONG).show();
                        break;
                    }
                }else{
                    counter = 9;
                    set();
                }
                break;
            case R.id.button7:
                if(counter == newRand.getArray()[6]) {
                    valid(b, newRand.getArray()[6]);
                    counter -= 1;
                     if (newRand.getArray()[6] == 1) {
                        Toast.makeText(MainActivity.this,
                                "END GAME!", Toast.LENGTH_LONG).show();
                        break;
                    }
                }else{
                    counter = 9;
                    set();
                }
                break;
            case R.id.button8:
                if(counter == newRand.getArray()[7]) {
                    valid(b, newRand.getArray()[7]);
                    counter -= 1;
                     if (newRand.getArray()[7] == 1) {
                        Toast.makeText(MainActivity.this,
                                "END GAME!", Toast.LENGTH_LONG).show();
                        break;
                    }
                }else{
                    counter = 9;
                    set();
                }
                break;
            case R.id.button9:
                if(counter == newRand.getArray()[8]) {
                    valid(b, newRand.getArray()[8]);
                    counter -= 1;
                    if (newRand.getArray()[8] == 1) {
                        Toast.makeText(MainActivity.this,
                                "END GAME!", Toast.LENGTH_LONG).show();
                        break;
                    }
                }else{
                    counter = 9;
                    set();
                }
                break;
            case R.id.button10://IF RESET NI SYA
                set();
                newRand.createnewSeq();
                Toast.makeText(MainActivity.this,
                        "CREATING NEW SEQUENCE", Toast.LENGTH_LONG).show();
                counter = 9;
                break;
        }
    }
}