package com.example.a4_pageandroidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class EducationBackground extends AppCompatActivity {
    SharedPreferences sp;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_education_background);

        sp = getSharedPreferences("My_Prefs", Activity.MODE_PRIVATE);

        button = (Button) findViewById(R.id.buttonnext2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("elem", ((EditText)findViewById(R.id.tv1n)).getText().toString());
                editor.putString("elemy", ((EditText)findViewById(R.id.tv2n)).getText().toString());
                editor.putString("his", ((EditText)findViewById(R.id.tv3n)).getText().toString());
                editor.putString("hsy", ((EditText)findViewById(R.id.tv4n)).getText().toString());
                editor.putString("coly", ((EditText)findViewById(R.id.tv5n)).getText().toString());
                editor.apply();
                openSkills();
            }
        });

        button = (Button) findViewById(R.id.back);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openMainMenu();
            }
        });
    }

    public void openSkills(){
        Intent intent = new Intent(this, Skills.class);
        startActivity(intent);
    }

    public void openMainMenu(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}