package com.example.a4_pageandroidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    SharedPreferences sp;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sp = getSharedPreferences("My_Prefs", Activity.MODE_PRIVATE);

        button = (Button) findViewById(R.id.buttonnext);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("fname", ((EditText)findViewById(R.id.tx1n)).getText().toString());
                editor.putString("mname", ((EditText)findViewById(R.id.tx2n)).getText().toString());
                editor.putString("lname", ((EditText)findViewById(R.id.tx3n)).getText().toString());
                editor.putString("bday", ((EditText)findViewById(R.id.tx4n)).getText().toString());
                editor.putString("gender", ((EditText)findViewById(R.id.tx5n)).getText().toString());
                editor.apply();
                openEducationalBackground();
            }
        });
    }

    public void openEducationalBackground (){
        Intent intent = new Intent(this, EducationBackground.class);
        startActivity(intent);
    }
}