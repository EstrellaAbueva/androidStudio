package com.example.a4_pageandroidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Skills extends AppCompatActivity {
    SharedPreferences sp;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_skills);

        sp = getSharedPreferences("My_Prefs", Activity.MODE_PRIVATE);

        button = (Button) findViewById(R.id.buttonnext3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("skil1", ((EditText)findViewById(R.id.tw1n)).getText().toString());
                editor.putString("skil2", ((EditText)findViewById(R.id.tw2n)).getText().toString());
                editor.putString("skil3", ((EditText)findViewById(R.id.tw3n)).getText().toString());
                editor.putString("skil4", ((EditText)findViewById(R.id.tw4n)).getText().toString());
                editor.putString("skil5", ((EditText)findViewById(R.id.tw5n)).getText().toString());
                editor.apply();
                openSummary();
            }
        });

        button = (Button) findViewById(R.id.back2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openEduc();
            }
        });
    }

    public void openSummary(){
        Intent intent = new Intent(this, Summary.class);
        startActivity(intent);
    }

    public void openEduc(){
        Intent intent = new Intent(this, EducationBackground.class);
        startActivity(intent);
    }

}