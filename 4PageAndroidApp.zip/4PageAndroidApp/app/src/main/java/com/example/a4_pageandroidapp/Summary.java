package com.example.a4_pageandroidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Summary extends AppCompatActivity {
    SharedPreferences sp;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_summary);
        sp = getSharedPreferences("My_Prefs", Activity.MODE_PRIVATE);

        ((TextView)findViewById(R.id.dispname)).setText(sp.getString("fname","") + " " + sp.getString("mname", "") + " " + sp.getString("lname", ""));
        ((TextView)findViewById(R.id.dispBirth)).setText(sp.getString("bday","") );
        ((TextView)findViewById(R.id.dispGender)).setText(sp.getString("gender","") );

        ((TextView)findViewById(R.id.dispElem)).setText(sp.getString("elem","") );
        ((TextView)findViewById(R.id.dispHS)).setText(sp.getString("his","") );
        ((TextView)findViewById(R.id.dispCollege)).setText(sp.getString("coly","") );

         ((TextView)findViewById(R.id.dispSk1)).setText(sp.getString("skil1","") );
         ((TextView)findViewById(R.id.dispSk2)).setText(sp.getString("skil2","") );
         ((TextView)findViewById(R.id.dispSk3)).setText(sp.getString("skil3","") );

    }
}