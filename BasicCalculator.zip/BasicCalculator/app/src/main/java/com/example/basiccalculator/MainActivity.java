package com.example.basiccalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import android.widget.Toast;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import java.util.*;

public class MainActivity extends AppCompatActivity {
    TextView toCalculate;
    TextView DisplayResult;

    String number = "";
    String formula = "";
    String pleaseChange = "";
    boolean operator = false;

    Stack <Double> stack = new Stack <>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initTextViews();
    }

    private void initTextViews(){
        toCalculate = (TextView)findViewById(R.id.writetext);
        DisplayResult = (TextView)findViewById(R.id.displayresult);
    }

    private void setNumber(String givenValue){
        number = number + givenValue;
        toCalculate.setText(number);
    }

    public void mplusOnClick(View view) throws ScriptException {
        Double result = null;
        ScriptEngine engine = new ScriptEngineManager().getEngineByName("rhino");

        try {
            result = (double)engine.eval(number);
            stack.push(result);
        } catch (ScriptException e){
            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
        }
        number ="";
    }

    public void mminusOnClick(View view) {
        stack.pop();
        number ="";
    }

    public void mcOnClick(View view) {
        stack.clear();
        number ="";
    }

    public void mrOnClick(View view) {
        try {
            setNumber(stack.peek().toString());
        }catch (Exception e){
            Toast.makeText(this, "Stack is Empty", Toast.LENGTH_SHORT).show();
        }
        number ="";
    }

    public void eraseOnClick(View view) {
        toCalculate.setText("");
        number = "";
        DisplayResult.setText("");
    }

    public void precentOnClick(View view) {
        operator = true;
        if(number.substring(number.length() - 1).equals("+") || number.substring(number.length() - 1).equals("-") || number.substring(number.length() - 1).equals("*")) {
            String text = number.substring(0, number.length() - 1);
            number = text;
            setNumber("/");
            toCalculate.setText(number);
        }else
            setNumber("/");

        toCalculate.setText(number);
    }

    boolean leftBracket = true;

    public void parenOnClick(View view) {
        if(leftBracket){
            setNumber("(");
            leftBracket = false;
        }else{
            setNumber(")");
            leftBracket = true;
        }
    }

    public void BackspaceClick(View view) {
        String text = number.substring(0, number.length() - 1);
        number = text;
    }

    public void sevenOnClick(View view){
        setNumber("7");
    }

    public void eightOnClick(View view) {
        setNumber("8");
    }

    public void nineOnClick(View view) {
        setNumber("9");
    }

    public void multiplyOnClick(View view) {
        operator = true;
        formula = "*";
        if(number.substring(number.length() - 1).equals("+") || number.substring(number.length() - 1).equals("-") || number.substring(number.length() - 1).equals("/")) {
            String text = number.substring(0, number.length() - 1);
            number = text;
            setNumber("*");
            toCalculate.setText(number);
        }else
            setNumber("*");

        toCalculate.setText(number);
    }

    public void fourOnClick(View view) {
        setNumber("4");
    }

    public void fiveOnClick(View view) {
        setNumber("5");
    }

    public void sixOnClick(View view) {
        setNumber("6");
    }

    public void minusOnClick(View view) {
        operator = true;
        formula = "-";
        if(number.substring(number.length() - 1).equals("+") || number.substring(number.length() - 1).equals("/" ) || number.substring(number.length() - 1).equals( "*")) {
            String text = number.substring(0, number.length() - 1);
            number = text;
            setNumber("-");
            toCalculate.setText(number);
        }else
            setNumber("-");

        toCalculate.setText(number);
    }

    public void oneOnClick(View view) {
        setNumber("1");
    }

    public void twoOnClick(View view) {
        setNumber("2");
    }

    public void threeOnClick(View view) {
        setNumber("3");
    }

    public void plusOnClick(View view) {
        operator = true;
        formula = "+";
        if(number.substring(number.length() - 1).equals("/") || number.substring(number.length() - 1).equals("-") || number.substring(number.length() - 1).equals("*")) {
            String text = number.substring(0, number.length() - 1);
            number = text;
            setNumber("+");
            toCalculate.setText(number);
        }else
            setNumber("+");

        toCalculate.setText(number);
    }

    public void zeroOnClick(View view) {
        setNumber("0");
    }

    public void decimalOnClick(View view) {
        setNumber(".");
    }

    private boolean isNumeric(char c) {
        if((c <= '9' && c >= '0') || c == '.')
            return true;

        return false;
    }

    public void equalsOnClick(View view) {
        Double result = null;
        ScriptEngine engine = new ScriptEngineManager().getEngineByName("rhino");

        try {
            result = (double)engine.eval(number);
        } catch (ScriptException e){
            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
        }

        if(result != null)
            DisplayResult.setText(String.valueOf(result.doubleValue()));

        toCalculate.setText("");
    }

    public void compute(){
        double result = 0;
        if(number.contains("+")){
            String[] strArray = number.split("\\+");
            for(int i = 0; i < strArray.length; i++)
                result += i;
        }else if(number.contains("-")){
            String[] strArray = number.split("-");
            for(int i = 0; i < strArray.length; i++)
                result -= i;
        }else if(number.contains("x")){
            String[] strArray = number.split("x");
            for(int i = 0; i < strArray.length; i++)
                result *= i;
        }else if(number.contains("/")){
            String[] strArray = number.split("/");
            for(int i = 0; i < strArray.length; i++)
                result /= i;
        }

        int finalans = (int) result;

        DisplayResult.setText(String.format("%d", finalans));
    }
}